/**
 * CONTROL DE ARTES – API sobre Google Sheets
 * ------------------------------------------------------------
 * Pega este archivo en Extensiones > Apps Script de tu hoja y
 * publícalo como "Aplicación web" (ver README.md).
 *
 * Hojas que usa: Seguimiento, Insumos, Historial.
 * Si no existen, se crean solas con sus encabezados.
 *
 * Seguridad opcional: en Configuración del proyecto > Propiedades
 * del script, crea la propiedad CLAVE_ACCESO con una clave. La app
 * pedirá esa clave para leer y guardar.
 */

const HOJAS = {
  Seguimiento: ['ID','LINEA','ITEM','COD_GRANEL','PRODUCTO','PRIORIDAD','PAIS','STATUS_ID','DETALLE',
    'FECHA_APROBACION','REGISTRO_REGULATORIO','ARTES_DISENO','FECHA_CARGA_ARTE','CARGA_SAP_ALT',
    'FECHA_CARGA_SAP','TAMBIEN_APLICA_A','PROYECCION_AGOTAMIENTO','LEAD_TIME','FECHA_ING_MATERIALES',
    'FECHA_ING_EMBALAJES','FECHA_INICIO_PRODUCCION','ACTUALIZADO','ACTUALIZADO_POR'],
  Insumos: ['ID','COD_GRANEL','PRODUCTO','PAIS','STATUS','FECHA_APROBACION','COD_SAP','INSUMO',
    'STOCK_FX','STOCK_PROVEEDOR','CONSUMO','ACTUALIZADO','ACTUALIZADO_POR'],
  Historial: ['FECHA','HOJA','REGISTRO_ID','PRODUCTO','PAIS','CAMPO','ANTES','DESPUES','USUARIO']
};
const PREFIJO = { Seguimiento: 'R-', Insumos: 'I-' };
const EDITABLES = ['Seguimiento', 'Insumos'];
const NUMERICOS = ['PROYECCION_AGOTAMIENTO','LEAD_TIME','STOCK_FX','STOCK_PROVEEDOR','CONSUMO'];
const ESTADOS_ID  = ['PENDIENTE','EN PROCESO','OBSERVADO','APROBADO PARCIALMENTE','APROBADO'];
const ESTADOS_REG = ['PENDIENTE','EN PROCESO','OBSERVADO','APROBADO'];

/* ---------- Menú dentro de Google Sheets ---------- */
function onOpen() {
  SpreadsheetApp.getUi().createMenu('Control de Artes')
    .addItem('Configurar hojas', 'configurarHojas')
    .addToUi();
}

/* ---------- Endpoints ---------- */
function doGet(e) {
  return responder(function () {
    verificarClave(e.parameter.key);
    return {
      Seguimiento: leer('Seguimiento'),
      Insumos: leer('Insumos'),
      Historial: leer('Historial').slice(-600).reverse(),
      hojaUrl: SpreadsheetApp.getActive().getUrl(),
      servidor: new Date().toISOString()
    };
  });
}

function doPost(e) {
  return responder(function () {
    const b = JSON.parse((e.postData && e.postData.contents) || '{}');
    verificarClave(b.key);
    if (EDITABLES.indexOf(b.sheet) < 0) throw new Error('Hoja no permitida: ' + b.sheet);
    const lock = LockService.getScriptLock();
    lock.waitLock(15000);
    try {
      if (b.action === 'create') return crear(b);
      if (b.action === 'update') return actualizar(b);
      if (b.action === 'delete') return eliminar(b);
      throw new Error('Acción desconocida: ' + b.action);
    } finally {
      lock.releaseLock();
    }
  });
}

/* ---------- Operaciones ---------- */
function crear(b) {
  const sh = hoja(b.sheet), h = encabezados(sh);
  const id = nuevoId(sh, h, PREFIJO[b.sheet]);
  const data = Object.assign({}, b.data || {}, {
    ID: id, ACTUALIZADO: ahoraIso(), ACTUALIZADO_POR: b.user || ''
  });
  sh.appendRow(h.map(function (c) { return aCelda(data[c], c); }));
  const logs = registrar([[b.sheet, id, data.PRODUCTO || data.INSUMO || '', data.PAIS || '', '(registro)', '', 'Creado', b.user]]);
  return { ok: true, record: normalizar(h, data), logs: logs };
}

function actualizar(b) {
  const sh = hoja(b.sheet), h = encabezados(sh);
  const fila = buscarFila(sh, h, b.id);
  const rango = sh.getRange(fila, 1, 1, h.length);
  const vals = rango.getValues()[0];
  const filas = [];
  Object.keys(b.data || {}).forEach(function (campo) {
    const i = h.indexOf(campo);
    if (i < 0 || campo === 'ID' || campo === 'ACTUALIZADO' || campo === 'ACTUALIZADO_POR') return;
    const antes = aTexto(vals[i], campo);
    const despues = b.data[campo] == null ? '' : b.data[campo];
    if (String(antes) === String(despues)) return;
    vals[i] = aCelda(despues, campo);
    filas.push([campo, antes, despues]);
  });
  if (!filas.length) return { ok: true, record: filaAObjeto(h, vals), logs: [] };

  vals[h.indexOf('ACTUALIZADO')] = new Date();
  vals[h.indexOf('ACTUALIZADO_POR')] = b.user || '';
  rango.setValues([vals]);

  const prod = vals[h.indexOf('PRODUCTO')] || vals[h.indexOf('INSUMO')] || '';
  const pais = vals[h.indexOf('PAIS')] || '';
  const logs = registrar(filas.map(function (f) {
    return [b.sheet, b.id, prod, pais, f[0], f[1], f[2], b.user];
  }));
  return { ok: true, record: filaAObjeto(h, vals), logs: logs };
}

function eliminar(b) {
  const sh = hoja(b.sheet), h = encabezados(sh);
  const fila = buscarFila(sh, h, b.id);
  const vals = sh.getRange(fila, 1, 1, h.length).getValues()[0];
  sh.deleteRow(fila);
  const logs = registrar([[b.sheet, b.id, vals[h.indexOf('PRODUCTO')] || '', vals[h.indexOf('PAIS')] || '',
    '(registro)', '', 'Eliminado', b.user]]);
  return { ok: true, logs: logs };
}

/* ---------- Utilidades ---------- */
function responder(fn) {
  let out;
  try { out = fn(); } catch (err) { out = { error: String(err && err.message || err) }; }
  return ContentService.createTextOutput(JSON.stringify(out)).setMimeType(ContentService.MimeType.JSON);
}

function verificarClave(k) {
  const clave = PropertiesService.getScriptProperties().getProperty('CLAVE_ACCESO');
  if (clave && k !== clave) throw new Error('Clave de acceso incorrecta');
}

function hoja(nombre) {
  const ss = SpreadsheetApp.getActive();
  let sh = ss.getSheetByName(nombre);
  if (!sh) {
    sh = ss.insertSheet(nombre);
    sh.getRange(1, 1, 1, HOJAS[nombre].length).setValues([HOJAS[nombre]]).setFontWeight('bold');
    sh.setFrozenRows(1);
  }
  return sh;
}

function encabezados(sh) {
  return sh.getRange(1, 1, 1, sh.getLastColumn()).getValues()[0].map(function (x) { return String(x).trim(); });
}

function leer(nombre) {
  const sh = hoja(nombre);
  const last = sh.getLastRow();
  if (last < 2) return [];
  const vals = sh.getRange(1, 1, last, sh.getLastColumn()).getValues();
  const h = vals.shift().map(function (x) { return String(x).trim(); });
  return vals
    .filter(function (r) { return r.some(function (x) { return x !== '' && x !== null; }); })
    .map(function (r) { return filaAObjeto(h, r); });
}

function filaAObjeto(h, r) {
  const o = {};
  h.forEach(function (c, i) { if (c) o[c] = aTexto(r[i], c); });
  return o;
}

function normalizar(h, data) {
  const o = {};
  h.forEach(function (c) { o[c] = data[c] == null ? '' : data[c]; });
  return o;
}

function zona() { return SpreadsheetApp.getActive().getSpreadsheetTimeZone(); }
function ahoraIso() { return Utilities.formatDate(new Date(), zona(), "yyyy-MM-dd'T'HH:mm:ss"); }

function aTexto(v, campo) {
  if (v instanceof Date) {
    const conHora = campo === 'ACTUALIZADO' || campo === 'FECHA';
    return Utilities.formatDate(v, zona(), conHora ? "yyyy-MM-dd'T'HH:mm:ss" : 'yyyy-MM-dd');
  }
  return v;
}

function aCelda(v, campo) {
  if (v === undefined || v === null) return '';
  if (typeof v === 'string' && (campo.indexOf('FECHA') === 0 || campo === 'ACTUALIZADO')) {
    const m = v.match(/^(\d{4})-(\d{2})-(\d{2})(?:T(\d{2}):(\d{2}):?(\d{2})?)?/);
    if (m) return new Date(+m[1], +m[2] - 1, +m[3], +(m[4] || 0), +(m[5] || 0), +(m[6] || 0));
  }
  if (NUMERICOS.indexOf(campo) >= 0 && v !== '' && !isNaN(Number(v))) return Number(v);
  return v;
}

function buscarFila(sh, h, id) {
  const col = h.indexOf('ID') + 1;
  const last = sh.getLastRow();
  if (last < 2) throw new Error('Registro no encontrado: ' + id);
  const ids = sh.getRange(2, col, last - 1, 1).getValues();
  for (let i = 0; i < ids.length; i++) if (String(ids[i][0]) === String(id)) return i + 2;
  throw new Error('Registro no encontrado: ' + id);
}

function nuevoId(sh, h, prefijo) {
  const col = h.indexOf('ID') + 1, last = sh.getLastRow();
  let max = 0;
  if (last >= 2) sh.getRange(2, col, last - 1, 1).getValues().forEach(function (r) {
    const n = parseInt(String(r[0]).replace(/\D/g, ''), 10);
    if (n > max) max = n;
  });
  return prefijo + ('0000' + (max + 1)).slice(-4);
}

function registrar(filas) {
  if (!filas.length) return [];
  const sh = hoja('Historial');
  const ahora = new Date();
  const datos = filas.map(function (f) { return [ahora].concat(f.map(function (x) { return x == null ? '' : x; })); });
  sh.getRange(sh.getLastRow() + 1, 1, datos.length, datos[0].length).setValues(datos);
  const h = HOJAS.Historial;
  return datos.map(function (r) { return filaAObjeto(h, r); });
}

/* ---------- Configuración inicial (ejecutar una vez) ---------- */
function configurarHojas() {
  Object.keys(HOJAS).forEach(function (n) {
    const sh = hoja(n);
    const h = encabezados(sh);
    HOJAS[n].forEach(function (c) {
      if (h.indexOf(c) < 0) sh.getRange(1, sh.getLastColumn() + 1).setValue(c).setFontWeight('bold');
    });
    sh.setFrozenRows(1);
    const hh = encabezados(sh);
    hh.forEach(function (c, i) {
      if (c.indexOf('FECHA') === 0 || c === 'ACTUALIZADO')
        sh.getRange(2, i + 1, Math.max(sh.getMaxRows() - 1, 1), 1).setNumberFormat(c === 'ACTUALIZADO' || c === 'FECHA' ? 'dd/mm/yyyy hh:mm' : 'dd/mm/yyyy');
    });
  });
  const sh = hoja('Seguimiento'), h = encabezados(sh), filas = Math.max(sh.getMaxRows() - 1, 1);
  const regla = function (lista) {
    return SpreadsheetApp.newDataValidation().requireValueInList(lista, true).setAllowInvalid(true).build();
  };
  sh.getRange(2, h.indexOf('STATUS_ID') + 1, filas, 1).setDataValidation(regla(ESTADOS_ID));
  sh.getRange(2, h.indexOf('REGISTRO_REGULATORIO') + 1, filas, 1).setDataValidation(regla(ESTADOS_REG));
  sh.getRange(2, h.indexOf('ARTES_DISENO') + 1, filas, 1).setDataValidation(regla(ESTADOS_REG));
  sh.getRange(2, h.indexOf('LINEA') + 1, filas, 1).setDataValidation(regla(['Productos nuevos', 'Sabores naturales']));
  SpreadsheetApp.getActive().toast('Hojas listas para Control de Artes', 'Control de Artes', 5);
}
