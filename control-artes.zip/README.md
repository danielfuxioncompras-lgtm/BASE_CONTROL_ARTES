# Control de Artes · Seguimiento de embalajes

App web para seguir el avance de cada producto por país a través de sus seis etapas:
**I+D → Regulatorio → Artes / diseño → Carga SAP → Compras → Producción**.

- La **app** (`index.html`) vive en GitHub Pages.
- Los **datos** viven en Google Sheets (hojas `Seguimiento`, `Insumos` e `Historial`).
- Un **Apps Script** (`apps-script/Code.gs`) conecta ambos: lee y guarda, y anota cada cambio en `Historial` con el nombre de quien lo hizo.

Sin configurar nada, la app abre en **modo demostración** con los datos de tu Excel (los cambios se guardan solo en tu navegador).

```
index.html                    ← la app completa (un solo archivo)
apps-script/Code.gs           ← API para Google Sheets
datos/BASE_CONTROL_ARTES.xlsx ← tus datos ya ordenados para subir a Sheets
```

---

## 1. Preparar Google Sheets (5 min)

1. Sube `datos/BASE_CONTROL_ARTES.xlsx` a tu Google Drive.
2. Ábrelo con Google Sheets y ve a **Archivo → Guardar como hoja de cálculo de Google**. Trabaja siempre sobre esa copia.
3. En la hoja: **Extensiones → Apps Script**. Borra lo que aparece, pega todo el contenido de `apps-script/Code.gs` y guarda (💾).
4. En el selector de funciones elige `configurarHojas` y pulsa **Ejecutar**. Google pedirá permisos: acéptalos (es tu propio script).

### Clave de acceso (recomendado)
En Apps Script: **Configuración del proyecto (⚙️) → Propiedades del script → Agregar propiedad**
- Propiedad: `CLAVE_ACCESO`
- Valor: la clave que compartirás con tu equipo

## 2. Publicar la API

1. En Apps Script: **Implementar → Nueva implementación**.
2. Tipo: **Aplicación web**.
3. Ejecutar como: **Yo** · Quién tiene acceso: **Cualquier persona**.
4. **Implementar** y copia la URL que termina en `/exec`.

> Si más adelante editas `Code.gs`, usa **Implementar → Administrar implementaciones → ✏️ → Versión: nueva** para que la URL no cambie.

## 3. Publicar la app en GitHub Pages

1. Crea un repositorio nuevo en GitHub (por ejemplo `control-artes`).
2. Sube `index.html` (y si quieres, las otras carpetas).
3. **Settings → Pages → Build and deployment**: Source *Deploy from a branch*, Branch `main` y carpeta `/ (root)` → **Save**.
4. En uno o dos minutos la app estará en `https://TU-USUARIO.github.io/control-artes/`.

## 4. Conectar

Abre la app → **Ajustes** → pega la URL `/exec`, la clave y tu nombre → **Guardar y conectar**.

Para que todo el equipo quede conectado sin configurar nada, puedes poner la URL directamente en `index.html`:

```js
const CONFIG = {
  API_URL: 'https://script.google.com/macros/s/XXXX/exec',
  CLAVE: ''   // mejor que cada persona la escriba en Ajustes
};
```

> Un repositorio público deja ver el código a cualquiera. No escribas la clave en `index.html`; cada persona la ingresa una vez en **Ajustes** y queda guardada en su navegador.

---

## Cómo se calcula cada etapa

| Etapa | Se toma de | Se considera lista cuando |
|---|---|---|
| I+D | `STATUS_ID` | Aprobado o aprobado parcial |
| Regulatorio | `REGISTRO_REGULATORIO` | Aprobado |
| Artes / diseño | `ARTES_DISENO` | Aprobado |
| Carga SAP | `CARGA_SAP_ALT` o `FECHA_CARGA_SAP` | Tiene alguno de los dos |
| Compras | `FECHA_ING_EMBALAJES` (o materiales) | La fecha ya pasó (antes: *Programado*) |
| Producción | `FECHA_INICIO_PRODUCCION` | La fecha ya pasó (antes: *Programada*) |

La **etapa actual** de un registro es la primera que todavía no está lista.

**Alertas del panel**
- *Listos para artes*: I+D y Regulatorio aprobados, arte todavía no aprobado.
- *Embalajes por ingresar sin arte aprobado*: ingreso de embalajes en los próximos 45 días.
- *Con observaciones*: alguna etapa en estado Observado.

**Cobertura de insumos** = (stock Fx + stock proveedor) ÷ consumo mensual. Menos de 2 meses se marca en rojo; entre 2 y 4, en amarillo. Si falta el stock del proveedor, se muestra en gris con `*` y no se cuenta como crítico.

## Atajos
`/` buscar · `N` nuevo registro · `Esc` cerrar · `Ctrl/⌘ + S` guardar el registro abierto

## Editar directo en Sheets
Puedes seguir editando en la hoja. Respeta los encabezados de la fila 1 y deja la columna `ID` con un valor único (`R-0102`, `I-0333`…). Los cambios hechos directo en la hoja no se anotan en `Historial`; los hechos desde la app, sí.
